<?php
session_start();

$mesaj="";

if(isset($_POST["giris"])){

$kullanici=$_POST["kullanici"];
$sifre=$_POST["sifre"];

if($kullanici=="admin" && $sifre=="1234"){

$_SESSION["admin"]=true;

header("Location: panel.php");
exit();

}
else{
$mesaj="Hatalı giriş";
}

}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Giriş</title>
</head>

<body>

<h2>Admin Giriş</h2>

<p><?php echo $mesaj;?></p>

<form method="POST">

Kullanıcı Adı<br>
<input type="text" name="kullanici"><br><br>

Şifre<br>
<input type="password" name="sifre"><br><br>

<button name="giris">Giriş</button>

</form>

</body>
</html>