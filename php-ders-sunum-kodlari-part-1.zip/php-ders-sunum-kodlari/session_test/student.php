<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Öğrenci Not Hesaplama</title>
<style>
body{
    font-family: Arial;
}
table{
    border-collapse: collapse;
    margin-top:20px;
}
td,th{
    border:1px solid black;
    padding:8px;
}
.error{
    color:red;
}
</style>
</head>
<body>

<h2>Öğrenci Not Hesaplama Formu</h2>

<form method="POST">

Öğrenci Adı:<br>
<input type="text" name="ad"><br><br>

Öğrenci Numarası:<br>
<input type="text" name="numara"><br><br>

Vize Notu:<br>
<input type="number" name="vize"><br><br>

Final Notu:<br>
<input type="number" name="final"><br><br>

<input type="submit" value="Hesapla">

</form>

<?php

if($_SERVER["REQUEST_METHOD"]=="POST"){

$ad=$_POST["ad"];
$numara=$_POST["numara"];
$vize=$_POST["vize"];
$final=$_POST["final"];

if(empty($ad) || empty($numara) || $vize==="" || $final===""){
    echo "<p class='error'>Tüm alanları doldurunuz!</p>";
}
else{

    if($vize<0 || $vize>100 || $final<0 || $final>100){
        echo "<p class='error'>Notlar 0 ile 100 arasında olmalıdır!</p>";
    }
    else{

        $sonuc = ($vize*0.4)+($final*0.6);

        if($sonuc>=50){
            $durum="Geçti";
        }else{
            $durum="Kaldı";
        }

        echo "<h3>Sonuç</h3>";

        echo "<table>";
        echo "<tr>
                <th>Ad</th>
                <th>Numara</th>
                <th>Vize</th>
                <th>Final</th>
                <th>Yıl Sonu</th>
                <th>Durum</th>
              </tr>";

        echo "<tr>
                <td>$ad</td>
                <td>$numara</td>
                <td>$vize</td>
                <td>$final</td>
                <td>$sonuc</td>
                <td>$durum</td>
              </tr>";

        echo "</table>";

    }
}

}

?>

</body>
</html>