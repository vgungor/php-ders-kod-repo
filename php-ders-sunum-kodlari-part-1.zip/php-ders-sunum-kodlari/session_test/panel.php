<?php
session_start();

/* Logout işlemi */

if(isset($_POST["logout"])){

    $_SESSION = [];
    session_destroy();
    header("Location:index.php");
    exit();
}

/* Admin kontrolü */

if(!isset($_SESSION["admin"])){
    header("Location:admin.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Panel</title>

<style>
    table{
    border-collapse:collapse;
    margin-top:20px;
    }

    td,th{
    border:1px solid black;
    padding:8px;
    }

    nav{
    background:#333;
    padding:10px;
    }

    nav a{
    color:white;
    margin-right:15px;
    text-decoration:none;
    }

    .logout{
    float:right;
    }
</style>

</head>

<body>

<nav>
<a href="index.php">Ana Sayfa</a>

<form method="POST" class="logout" style="display:inline;">
    <button name="logout">Logout</button>
</form>

</nav>

<h2>Tüm Öğrenciler</h2>

<table>

<tr>
<th>Ad</th>
<th>Numara</th>
<th>Vize</th>
<th>Final</th>
<th>Ortalama</th>
<th>Durum</th>
</tr>

<?php

if(isset($_SESSION["ogrenciler"])){

foreach($_SESSION["ogrenciler"] as $o){

echo "<tr>
<td>".$o["ad"]."</td>
<td>".$o["numara"]."</td>
<td>".$o["vize"]."</td>
<td>".$o["final"]."</td>
<td>".$o["sonuc"]."</td>
<td>".$o["durum"]."</td>
</tr>";

}

}

?>

</table>

</body>
</html>