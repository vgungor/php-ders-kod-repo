<?php
session_start();

if(!isset($_SESSION["ogrenciler"])){
    $_SESSION["ogrenciler"] = [];
}

$mesaj = "";

/* Öğrenci ekleme */
if(isset($_POST["ekle"])){

$ad = $_POST["ad"];
$numara = $_POST["numara"];
$vize = $_POST["vize"];
$final = $_POST["final"];

if(empty($ad) || empty($numara) || $vize==="" || $final===""){
    $mesaj="Tüm alanları doldurunuz";
}
else{

    if($vize<0 || $vize>100 || $final<0 || $final>100){
        $mesaj="Notlar 0-100 arasında olmalıdır";
    }
    else{

        $sonuc = ($vize*0.4)+($final*0.6);
        $durum = $sonuc>=50 ? "Geçti" : "Kaldı";

        $ogrenci = [
            "ad"=>$ad,
            "numara"=>$numara,
            "vize"=>$vize,
            "final"=>$final,
            "sonuc"=>$sonuc,
            "durum"=>$durum
        ];

        $_SESSION["ogrenciler"][]=$ogrenci;

        $mesaj="Öğrenci kaydedildi";
    }

}

}

/* Admin giriş kontrolü */
$admin=false;

if(isset($_POST["admin_giris"])){

$kullanici=$_POST["kullanici"];
$sifre=$_POST["sifre"];

if($kullanici=="admin" && $sifre=="1234"){
    $admin=true;
}else{
    $mesaj="Admin bilgileri hatalı";
}

}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Öğrenci Sistemi</title>

<style>
table{
border-collapse:collapse;
margin-top:20px;
}

td,th{
border:1px solid black;
padding:8px;
}
</style>

</head>
<body>

<h2>Öğrenci Not Girişi</h2>

<p><?php echo $mesaj; ?></p>

<form method="POST">

Ad<br>
<input type="text" name="ad"><br><br>

Numara<br>
<input type="text" name="numara"><br><br>

Vize<br>
<input type="number" name="vize"><br><br>

Final<br>
<input type="number" name="final"><br><br>

<button name="ekle">Öğrenci Ekle</button>

</form>

<hr>

<h2>Admin Girişi</h2>

<form method="POST">

Kullanıcı Adı<br>
<input type="text" name="kullanici"><br><br>

Şifre<br>
<input type="password" name="sifre"><br><br>

<button name="admin_giris">Giriş Yap</button>

</form>

<?php

/* Admin ise tabloyu göster */

if($admin){

echo "<h2>Tüm Öğrenciler</h2>";

echo "<table>";

echo "<tr>
<th>Ad</th>
<th>Numara</th>
<th>Vize</th>
<th>Final</th>
<th>Ortalama</th>
<th>Durum</th>
</tr>";

foreach($_SESSION["ogrenciler"] as $o){

echo "<tr>
<td>".$o["ad"]."</td>
<td>".$o["numara"]."</td>
<td>".$o["vize"]."</td>
<td>".$o["final"]."</td>
<td>".$o["sonuc"]."</td>
<td>".$o["durum"]."</td>
</tr>";

}

echo "</table>";

}

?>

</body>
</html>