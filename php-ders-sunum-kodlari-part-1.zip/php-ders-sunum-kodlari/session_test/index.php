<?php
session_start();

if(!isset($_SESSION["ogrenciler"])){
    $_SESSION["ogrenciler"]=[];
}

$mesaj="";
$ogrenciSonuc=null;

if(isset($_POST["ekle"])){

$ad=$_POST["ad"];
$numara=$_POST["numara"];
$vize=$_POST["vize"];
$final=$_POST["final"];

if(empty($ad)||empty($numara)||$vize===""||$final===""){
$mesaj="Tüm alanları doldurun";
}
else{

if($vize<0||$vize>100||$final<0||$final>100){
$mesaj="Notlar 0-100 arasında olmalı";
}
else{

$sonuc=($vize*0.4)+($final*0.6);
$durum=$sonuc>=50?"Geçti":"Kaldı";

$ogrenci=[
"ad"=>$ad,
"numara"=>$numara,
"vize"=>$vize,
"final"=>$final,
"sonuc"=>$sonuc,
"durum"=>$durum
];

$_SESSION["ogrenciler"][]=$ogrenci;

$ogrenciSonuc=$ogrenci;

}

}

}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Öğrenci Sistemi</title>

<style>

nav{
background:#333;
padding:10px;
}

nav a{
color:white;
margin-right:15px;
text-decoration:none;
}

table{
border-collapse:collapse;
margin-top:20px;
}

td,th{
border:1px solid black;
padding:8px;
}

</style>

</head>

<body>

<nav>
<a href="index.php">Ana Sayfa</a>
<a href="admin.php">Admin</a>
</nav>

<h2>Öğrenci Not Girişi</h2>

<p><?php echo $mesaj;?></p>

<form method="POST">

Ad<br>
<input type="text" name="ad"><br><br>

Numara<br>
<input type="text" name="numara"><br><br>

Vize<br>
<input type="number" name="vize"><br><br>

Final<br>
<input type="number" name="final"><br><br>

<button name="ekle">Gönder</button>

</form>

<?php

if($ogrenciSonuc){

echo "<h3>Sonucunuz</h3>";

echo "<table>";

echo "<tr>
<th>Ad</th>
<th>Numara</th>
<th>Vize</th>
<th>Final</th>
<th>Ortalama</th>
<th>Durum</th>
</tr>";

echo "<tr>
<td>".$ogrenciSonuc["ad"]."</td>
<td>".$ogrenciSonuc["numara"]."</td>
<td>".$ogrenciSonuc["vize"]."</td>
<td>".$ogrenciSonuc["final"]."</td>
<td>".$ogrenciSonuc["sonuc"]."</td>
<td>".$ogrenciSonuc["durum"]."</td>
</tr>";

echo "</table>";

}

?>

</body>
</html>