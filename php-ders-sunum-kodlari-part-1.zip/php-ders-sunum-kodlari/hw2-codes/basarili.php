<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Başarılı</title>
    </head>
    <body>
        <h2>Giriş Başarılı</h2>
        <p>Sisteme hoşgeldiniz.</p>
        <a href="index.php">Ana Sayfa</a>
    </body>
</html>