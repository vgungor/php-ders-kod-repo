<?php

    if(isset($_POST["giris"])){

        $kullanici=$_POST["kullanici"];
        $sifre=$_POST["sifre"];

        if($kullanici=="admin" && $sifre=="1234"){
            header("Location:basarili.php");
            exit();
        }
        else{
            header("Location:kayit.php");
            exit();
        }
    }

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Giriş</title>
    </head>
        <body>
        <h2>Giriş Formu</h2>
        <form method="POST">
            Kullanıcı Adı<br>
            <input type="text" name="kullanici"><br><br>
            Şifre<br>
            <input type="password" name="sifre"><br><br>
            <button name="giris">Giriş Yap</button>
        </form>

    </body>
</html>