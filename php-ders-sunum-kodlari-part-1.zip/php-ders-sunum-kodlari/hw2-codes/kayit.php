<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Kayıt</title>
    </head>

    <body>
        <h2>Kayıt Formu</h2>
        <form>
            Ad<br>
            <input type="text"><br><br>
            Email<br>
            <input type="email"><br><br>
            Kullanıcı Adı<br>
            <input type="text"><br><br>
            Şifre<br>
            <input type="password"><br><br>
            <button>Kayıt Ol</button>
        </form>

        <a href="index.php">Giriş Sayfasına Dön</a>

    </body>
</html>