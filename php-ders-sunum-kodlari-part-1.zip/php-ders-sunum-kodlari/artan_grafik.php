<?php
// Sayfa ilk açıldığında hataları engellemek için varsayılan değerleri atıyoruz
// ?? operatörü: "Varsa onu kullan, yoksa sağdaki değeri ata" demektir.

$toplam = $_POST['eski_toplam'] ?? 0;
$liste  = $_POST['eski_liste'] ?? "0"; 

if (isset($_POST['ekle'])) {
    $gelen_sayi = $_POST['sayi'] ?? 0;

    // += Operatörü ile üzerine ekle
    $toplam += $gelen_sayi; 

    // Yeni değeri listenin sonuna ekle
    $liste .= "," . $toplam; 
}

// Grafik için stringi diziye çevir
$grafik_icin_dizi = explode(",", $liste);
?>

<!DOCTYPE html>
<html>
<head>
    <title>En Basit Grafik</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

    <h3>Toplam: <?php echo $toplam; ?></h3>

    <form method="post">
        <input type="hidden" name="eski_toplam" value="<?php echo $toplam; ?>">
        <input type="hidden" name="eski_liste" value="<?php echo $liste; ?>">
        
        <input type="number" name="sayi" required>
        <button type="submit" name="ekle">Ekle</button>
        <a href="?">Sıfırla</a> <!-- <a> etiketi içindeki href="?" ifadesi, teknik olarak "bulunduğun sayfayı tüm parametreleri temizleyerek yeniden yükle" demektir. -->
    </form>

    <canvas id="grafik" width="400" height="200"></canvas>

    <script>
        var ctx = document.getElementById('grafik');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(range(1, count($grafik_icin_dizi))); ?>,
                datasets: [{
                    label: 'Değerler',
                    data: <?php echo json_encode($grafik_icin_dizi); ?>
                }]
            }
        });
    </script>

</body>
</html>