<!DOCTYPE html>
<html>
    <head><title>Hesap Makinası</title></head>
<body>
    <form method="GET">
        <input type="number" name="s1" placeholder="1. Sayı" required>
        
        <select name="islem">
            <option value="topla">Topla (+)</option>
            <option value="cikar">Çıkar (-)</option>
            <option value="carp">Çarp (*)</option>
            <option value="bol">Böl (/)</option>
        </select>
        
        <input type="number" name="s2" placeholder="2. Sayı" required>
        <input type="submit" value="Hesapla">
    </form>

    <?php
        // Gelen verileri kontrol edelim
        if (isset($_GET['s1']) && isset($_GET['islem']) && isset($_GET['s2'])) {
            $sayi1 = $_GET['s1'];
            $islem = $_GET['islem'];
            $sayi2 = $_GET['s2'];
            $sonuc = 0;

            // Karşılaştırma Operatörleri ile kontrol 
            if ($islem == "topla") {
                $sonuc = $sayi1 + $sayi2; // Toplama [cite: 352]
            } 
            elseif ($islem == "cikar") {
                $sonuc = $sayi1 - $sayi2; // Çıkarma [cite: 352]
            } 
            elseif ($islem == "carp") {
                $sonuc = $sayi1 * $sayi2; // Çarpma [cite: 352]
            } 
            // Mantıksal Operatör Kontrolü: İşlem bölmeyse VE sayı 0 değilse [cite: 370]
            elseif ($islem == "bol" && $sayi2 != 0) {
                $sonuc = $sayi1 / $sayi2; // Bölme [cite: 352]
            } 
            else {
                $sonuc = "Hata: Geçersiz işlem veya 0'a bölme!";
            }

            echo "<h3>Sonuç: $sonuc</h3>";
        }
        ?>
</body>
</html>